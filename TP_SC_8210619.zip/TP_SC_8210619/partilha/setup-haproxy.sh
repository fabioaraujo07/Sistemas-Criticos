#!/bin/bash

#Inicial Configuration
sudo apt update

# Install HAProxy, Pacemaker, Corosync and Pcs
sudo apt install haproxy -y
