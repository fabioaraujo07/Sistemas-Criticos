#!/bin/bash

# Install MariaDB, Pacemaker, Corosync and Pcs
sudo apt install mariadb-server pacemaker corosync pcs -y
